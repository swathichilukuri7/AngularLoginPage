import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddUserComponent } from '../../../admin/users/add-user/add-user.component';
import { ViewuserComponent } from '../../../admin/users/viewuser/viewuser.component';
import { EditUserComponent } from '../../../admin/users/edit-user/edit-user.component';
import { UsersComponent } from '../../../admin/users/users.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    UsersComponent,
    AddUserComponent,
    ViewuserComponent,
    EditUserComponent,],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class UsersModule { }
