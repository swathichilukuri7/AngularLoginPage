import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UserHttpClientService } from '../../../service/user-http-client.service';
import { AddUserComponent } from './add-user.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { UsersComponent } from '../users.component';
import { ViewuserComponent } from '../viewuser/viewuser.component';
import { By } from '@angular/platform-browser';
import { EditUserComponent } from '../edit-user/edit-user.component';

describe('AddUserComponent', () => {
  let component: AddUserComponent;
  let fixture: ComponentFixture<AddUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUserComponent, UsersComponent, ViewuserComponent, EditUserComponent ],
      imports: [
        ReactiveFormsModule,
        RouterTestingModule,
        FormsModule
      ],
      providers:[
        { provide:UserHttpClientService, useClass : UserHttpClientServicestub },

      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUserComponent);
    component = fixture.componentInstance;
    // component.ngOnInit();
    component.user=name;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call the addUser method', () => {
    fixture.detectChanges();
    spyOn(component,'addUser');
    const el=fixture.debugElement.query(By.css('button')).nativeElement;
    el.click();
    expect(component.addUser).toHaveBeenCalledTimes(0);
  });

  it('form should be valid, if have any values', () => {
    let userName = component.addUserForm.controls["name"];
    userName.setValue("harika");
    let userEmail = component.addUserForm.controls["email"];
    userEmail.setValue("xyz@gmail.com");
    let userType= component.addUserForm.controls["type"];
    userType.setValue("Admin");
    let userPassword= component.addUserForm.controls["password"];
    userPassword.setValue("bb");
    expect(component.addUserForm.valid).toBeTruthy();
  });

  it('form should be invalid when empty', () => { 
    let userName = component.addUserForm.controls["name"];
    userName.setValue("");
    let userEmail = component.addUserForm.controls["email"];
    userName.setValue("");
    let userType= component.addUserForm.controls["type"];
    userType.setValue("");
    let userPassword= component.addUserForm.controls["password"];
    userPassword.setValue("");
    expect(component.addUserForm.valid).toBeFalsy();
  });

  it('should create a form with 3 controls', () => {

    expect(component.addUserForm.contains('name')).toBe(true);
    expect(component.addUserForm.contains('password')).toBeTruthy();
    expect(component.addUserForm.contains('email')).toBeTruthy();
    expect(component.addUserForm.contains('type')).toBeTruthy();

    })

});

class UserHttpClientServicestub{
    addUser() {
      
    }
  }

