import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { User } from '../../../model/User';
import { UserHttpClientService } from '../../../service/user-http-client.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { UtilsService } from '../../../shared/utils.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  @Input()
  user: User
  @Output()
  userAddedEvent = new EventEmitter();


  constructor(private userhttpClientService: UserHttpClientService,
    private router: Router,
    private utilsService: UtilsService,
    private formBuilder: FormBuilder,
  ) { }

  password: string;
  name: string;
  id: number;
  typesList = ["Admin", "User"];
  email: string;
  addUserForm: FormGroup;

  ngOnInit() {

    this.addUserForm = this.formBuilder.group({
      // id: [],
      name: ['', [Validators.required, Validators.pattern(this.utilsService.namePattern)]],
      type: ['', [Validators.required]],
      password: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(this.utilsService.emailIdPattern)]],
    });
    // this.addUserForm.setValue(this.newUser);
    //we use this to get values while update

    // this.addUserForm.controls["name"].setValue(this.user.name);
    // this.addUserForm.controls["type"].setValue(this.user.type);
    // this.addUserForm.controls["password"].setValue(this.user.password);

  }

  addUser() {
    if (this.addUserForm.invalid) {
      return;
    }
    else {
      this.userhttpClientService.addUser(this.addUserForm.value).subscribe(
        (data: any) => {
          this.utilsService.showSuccessAddAlert();
          this.userAddedEvent.emit();
          this.router.navigate(['admin', 'users']);
        }
      );
    }
  }
  get f() {
    return this.addUserForm.controls;
  }
}


