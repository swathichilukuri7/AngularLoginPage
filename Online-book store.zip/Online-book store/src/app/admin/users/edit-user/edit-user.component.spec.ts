import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditUserComponent } from './edit-user.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { UsersComponent } from '../users.component';
import { UserHttpClientService } from '../../../service/user-http-client.service';
import { of , Observable} from 'rxjs';
import { User } from 'src/app/model/User';
import { AddUserComponent } from '../add-user/add-user.component';
import { ViewuserComponent } from '../viewuser/viewuser.component';

describe('EditUserComponent', () => {
  let component: EditUserComponent;
  let fixture: ComponentFixture<EditUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditUserComponent, UsersComponent, AddUserComponent, ViewuserComponent ],
      imports: [
        ReactiveFormsModule,
        RouterTestingModule,
        FormsModule
      ],
      providers:[
        { provide:UserHttpClientService, useClass : UserHttpClientServicestub },

      ]
    })
    .compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(EditUserComponent);
    component = fixture.componentInstance;
    // component.ngOnInit;
    component.user=name;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('sending form values to the service onSubmit method', () => {
    // assuming the property on the component is named jobForm
    const form = component.updateUserForm;
    form.patchValue({'title': 'a spec title'}); 
});
});

class UserHttpClientServicestub{
    getUserById(){
      return of([]);
      // return of([]);
    }
}