import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { User } from '../../../model/User';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { UserHttpClientService } from '../../../service/user-http-client.service';
import { UtilsService } from '../../../shared/utils.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  @Input()
  user: User;
  @Output()
  userUpdatedEvent = new EventEmitter();

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private userhttpClientService: UserHttpClientService,
    private utilsService: UtilsService
  ) { }

  newUser:User;
  updateUserForm: FormGroup;
  password: string;
  name: string;
  id: number;
  typesList = ["Admin", "User"];
  addUserForm: FormGroup;
  submitted: boolean = false;

  ngOnInit() {
    // this.newUser = Object.assign({}, this.user);
    // console.log(this.newUser);
    this.userhttpClientService.getUserById(this.user.id)
      .subscribe(data => {
        console.log(data);
        // this.updateUserForm.setValue(data);
      });
      
    this.updateUserForm = this.formBuilder.group({
      id: [this.user.id],
      name: ['', [Validators.required, Validators.pattern(this.utilsService.namePattern)]],
      type: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern(this.utilsService.emailIdPattern)]],
    });
    // this.updateUserForm.setValue(this.newUser);
    this.updateUserForm.controls["name"].setValue(this.user.name);
    this.updateUserForm.controls["type"].setValue(this.user.type);
    this.updateUserForm.controls["email"].setValue(this.user.email);
    this.updateUserForm.controls["password"].setValue(this.user.password);
  }

  get f() {
    return this.updateUserForm.controls;
  }
  updateUser() {
    this.userhttpClientService.updateUser(this.updateUserForm.value).subscribe(
      (user) => {
        this.utilsService.showSuccessUpdateMsg();
        this.userUpdatedEvent.emit();
        this.router.navigate(['admin', 'users']);
      }
    );
  }
}


