import { Component, OnInit, Input, EventEmitter, Output} from '@angular/core';
import { User } from '../../../model/User';
import { UserHttpClientService } from '../../../service/user-http-client.service';
import { Router } from '@angular/router';
import { UtilsService } from 'src/app/shared/utils.service';

@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {

  @Input()
  user: User
  @Output()
  userDeletedEvent = new EventEmitter();

  constructor(private userhttpClientService: UserHttpClientService,
    private router: Router,
    private utilsService :UtilsService) { }

  ngOnInit() {
    // this.userhttpClientService.getUserById(this.user.id)
    // .subscribe( data => {
    //   console.log(data);
    // });
  }

  deleteUser() {
    this.userhttpClientService.deleteUser(this.user.id).subscribe(
      (user) => {
        this.utilsService.deleteUserMsg();
        this.userDeletedEvent.emit();
        this.router.navigate(['admin', 'users']);
      }
    );
  }
  editUser() {
    this.router.navigate(['admin', 'users'], { queryParams: { action: 'edit', id: this.user.id } });
  }
}
