import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewuserComponent } from './viewuser.component';
import { UserHttpClientService } from '../../../service/user-http-client.service';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { User } from 'src/app/model/User';
import { type } from 'os';
import { By } from '@angular/platform-browser';

describe('ViewuserComponent', () => {
  let component: ViewuserComponent;
  let fixture: ComponentFixture<ViewuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewuserComponent ],
      imports: [ RouterTestingModule,ReactiveFormsModule ],
      providers:[
        { provide:UserHttpClientService, useClass : UserHttpClientServicestub },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewuserComponent);
    component = fixture.componentInstance;
    component.user=name;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should be a edit button first on the page',()=>{
    const linkDes = fixture.debugElement.queryAll(By.css('button'));
    const nativeButton : HTMLButtonElement = linkDes[0].nativeElement;
    expect(nativeButton.textContent).toBe('Edit');

  })  
});

class UserHttpClientServicestub{
  deleteUser(id) {
  //   return ([]);
   }
}