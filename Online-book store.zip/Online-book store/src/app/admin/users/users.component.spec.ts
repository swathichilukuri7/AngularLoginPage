import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UserHttpClientService } from '../../service/user-http-client.service';
import { UsersComponent } from './users.component';
import { RouterTestingModule } from '@angular/router/testing';
import { AddUserComponent } from './add-user/add-user.component';
import { ViewuserComponent } from './viewuser/viewuser.component';
import { ReactiveFormsModule } from '@angular/forms';
import { Observable, of, observable } from 'rxjs';
import { By } from '@angular/platform-browser';
import { User } from 'src/app/model/User';
import { Component } from '@angular/core';
import { EditUserComponent } from '../users/edit-user/edit-user.component';

describe('UserComponent', () => {
   let component: UsersComponent;
  // let service: UserHttpClientService;
  let fixture: ComponentFixture<UsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UsersComponent, AddUserComponent, ViewuserComponent,EditUserComponent],
      imports: [
        RouterTestingModule,
        ReactiveFormsModule,
      ],
      providers: [
        { provide: UserHttpClientService, useClass: UserHttpClientServicestub },

      ],

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain h1 tag', () => {
    const h1Ele = fixture.debugElement.query(By.css('h1'));
    expect(h1Ele.nativeElement.textContent).toBe('Users Admin');
  });

  it('should minimum one add button on the page', () => {
    const buttons = fixture.debugElement.queryAll(By.css('button'));
    expect(buttons.length >= 1).toBeTruthy();
  });

  it('should be a add button first on the page', () => {
    const linkDes = fixture.debugElement.queryAll(By.css('button'));
    const nativeButton: HTMLButtonElement = linkDes[0].nativeElement;
    expect(nativeButton.textContent).toBe('Add User');

  });

  // it('should show one user details',()=>{ // need to resolve
  //   component.users[] =  of([
  //     { id:1, name:'hari',type:'admin',password:'12'},
  //   ]);
  //   fixture.detectChanges();
  //   const listItem = fixture.debugElement.queryAll(By.css('tr'));
  //   expect(listItem.length).toBe(1); 
  // });

  

  // it('should set users properties with values', () => {
  //   const users: User[] = [
  //     {
  //       id: 1,
  //       name: 'harika',
  //       type: 'user',
  //       password: 'abc',

  //     },
  //     {
  //       id: 2,
  //       name: 'hari',
  //       type: 'admin',
  //       password: 'abc',
  //     },
  //   ];
  //   spyOn(service, 'getUsers').and.callFake( () => {
  //     return observable.from([users]);
  //   });
  //   component.ngOnInit();
  //   expect(component.users).toEqual(users);
  // });

});


class UserHttpClientServicestub {
  getUsers() {
    return of([]);
  }
}