import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsComponent } from './products.component';
import { ProductHttpClientService } from '../../service/product-http-client.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddProductComponent } from '../products/add-product/add-product.component';
import { ViewProductComponent } from '../products/view-product/view-product.component';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { EditProductComponent } from '../products/edit-product/edit-product.component';

describe('BooksComponent', () => {
  let component: ProductsComponent;
  let fixture: ComponentFixture<ProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsComponent ,AddProductComponent, ViewProductComponent,EditProductComponent ],
      imports: [ RouterTestingModule, FormsModule, ReactiveFormsModule],
      providers:[
        {provide: ProductHttpClientService, useClass : ProductHttpClientServicestub },

      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should minimum one add button on the page',()=>{
    const buttons = fixture.debugElement.queryAll(By.css('button'));
    expect(buttons.length >= 1).toBeTruthy();
  })

});

class ProductHttpClientServicestub{
  getBooks() {
      return of([]);
    }
 }