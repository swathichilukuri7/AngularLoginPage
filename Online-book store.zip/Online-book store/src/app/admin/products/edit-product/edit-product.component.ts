import { Component, OnInit , Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { ProductHttpClientService } from '../../../service/product-http-client.service';
import { Book } from '../../../model/book';
import { UtilsService } from '../../../shared/utils.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, 
    private router: Router,
    private producthttpclientservice: ProductHttpClientService,
    private utilsService:UtilsService) { }

  @Input()
  book: Book;
  @Output()
  bookUpdatedEvent = new EventEmitter();

  updateBookForm:FormGroup;

  ngOnInit() {

    this.producthttpclientservice.getBookById(this.book.id)
    .subscribe( data => {
      console.log(data);
      // this.updateBookForm.setValue(data);
    });

    this.updateBookForm = this.formBuilder.group({
      id:[this.book.id],
      name:['', [Validators.required]],
      author: ['',[ Validators.required]],
      price: ['',[ Validators.required,Validators.pattern(this.utilsService.numberPattern)]],
      retrievedImage : [''],
    });
    this.updateBookForm.controls["name"].setValue(this.book.name);
    this.updateBookForm.controls["author"].setValue(this.book.author);
    this.updateBookForm.controls["price"].setValue(this.book.price);
    this.updateBookForm.controls["retrievedImage"].setValue(this.book.retrievedImage);
  }

  get f() {
    return this.updateBookForm.controls;
  }

  EditBook(){
  this.producthttpclientservice.updateBook(this.updateBookForm.value).subscribe(
    (book)=> {
      this.utilsService.showProductUpdateMsg();
      this.bookUpdatedEvent.emit();
      this.router.navigate(['admin', 'products']);
    }
  );
}
}
