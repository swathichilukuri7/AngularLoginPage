import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditProductComponent } from './edit-product.component';
import { ProductHttpClientService } from '../../../service/product-http-client.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { ProductsComponent } from '../products.component';
import { ViewuserComponent } from '../../users/viewuser/viewuser.component';
import { ViewProductComponent } from '../view-product/view-product.component';
import { AddProductComponent } from '../add-product/add-product.component';

describe('EditProductComponent', () => {
  let component: EditProductComponent;
  let fixture: ComponentFixture<EditProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditProductComponent, ProductsComponent, ViewProductComponent, AddProductComponent ],
      imports: [
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule
      ],
      providers:[
        {provide: ProductHttpClientService, useClass : ProductHttpClientServicestub },
        // {provide: HttpClient, useClass : HttpClientstub }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditProductComponent);
    component = fixture.componentInstance;
    component.book=name;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
class ProductHttpClientServicestub{
  getBookById(){
    return of([]);
  }
}
