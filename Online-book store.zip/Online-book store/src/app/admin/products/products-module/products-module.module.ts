import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductsComponent } from '../../../admin/products/products.component';
import { AddProductComponent } from '../../../admin/products/add-product/add-product.component';
import { ViewProductComponent } from '../../../admin/products/view-product/view-product.component';
import { EditProductComponent } from '../../../admin/products/edit-product/edit-product.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    ProductsComponent,
    AddProductComponent,
    ViewProductComponent,
    EditProductComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class ProductsModuleModule { }
