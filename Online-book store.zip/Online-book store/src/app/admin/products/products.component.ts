import { Component, OnInit } from '@angular/core';
import { Book } from '../../model/Book';
import { ProductHttpClientService } from '../../service/product-http-client.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  books: Array<Book>;
  action: string;
  selectedBook: Book;
  books1: Array<Book>;

  constructor(private producthttpclientservice: ProductHttpClientService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }
  datafromb: any;
  ngOnInit() {
    this.refreshData();
  }
  refreshData() {
    this.producthttpclientservice.getBooks().subscribe(
      response => {
        this.books = response;
        console.log(response);

        this.books = new Array<Book>();
        this.books1 = response;
        for (const book of this.books1) {

          const book2 = new Book();
          book2.id = book.id;
          book2.name = book.name;
          book2.retrievedImage = 'data:image/jpeg;base64,' + book.imgUrl;
          book2.author = book.author;
          book2.price = book.price;
          book2.imgUrl = book.imgUrl;
          this.books.push(book2);
        }
      }
    );

    this.activatedRoute.queryParams.subscribe(
      (params) => {
        const id = params['id'];
        this.action = params['action'];
        if (id) {
          this.selectedBook = this.books.find(book => {
            return book.id === +id;
          });
        }
      }
    );
  }



  addBook() {
    this.selectedBook = new Book();
    this.router.navigate(['admin', 'products'], { queryParams: { action: 'add' } });
  }

  viewBook(id: number) {
    this.router.navigate(['admin', 'products'], { queryParams: { id, action: 'view' } });
  }

}
