import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddProductComponent } from './add-product.component';
import { ProductHttpClientService } from '../../../service/product-http-client.service';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

describe('AddbookComponent', () => {
  let component: AddProductComponent;
  let fixture: ComponentFixture<AddProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddProductComponent ],
      imports: [
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule
      ],
      providers:[
        {provide: ProductHttpClientService, useClass : ProductHttpClientServicestub },
        {provide: HttpClient, useClass : HttpClientstub }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddProductComponent);
    component = fixture.componentInstance;
    component.book=name;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form should be invalid when empty', () => { 
    let itemName = component.addBookForm.controls["name"];
    itemName.setValue("");
    let author = component.addBookForm.controls["author"];
    author.setValue("");
    let itemPrice= component.addBookForm.controls["price"];
    itemPrice.setValue("");
    let file= component.addBookForm.controls["file"];
    file.setValue("");
    expect(component.addBookForm.valid).toBeFalsy();
  });
});

class ProductHttpClientServicestub{

}
class HttpClientstub{

}