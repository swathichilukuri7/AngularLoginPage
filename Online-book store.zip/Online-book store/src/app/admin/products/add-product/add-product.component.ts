import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Book } from '../../../model/Book';
import { ProductHttpClientService } from '../../../service/product-http-client.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { UtilsService } from '../../../shared/utils.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  @Input()
  book: Book;
  @Output()
  bookAddedEvent = new EventEmitter();

  public selectedFile;
  imgURL: any;
  addBookForm:FormGroup;

  constructor(private producthttpclientservice: ProductHttpClientService,
    private router: Router,
    private httpClient: HttpClient,
    private formBuilder: FormBuilder,
    private utilsService:UtilsService) { }

  ngOnInit() {
    this.addBookForm = this.formBuilder.group({
      id :[],
      name:['', [Validators.required]],
      author: ['',[ Validators.required]],
      price: ['',[ Validators.required,Validators.pattern(this.utilsService.numberPattern)]],
      file : ['', [Validators.required]],
    });
  }
  
  get f() {
    return this.addBookForm.controls;
  }
  selectFile(event) {
    this.selectedFile = event.target.files[0];

    // Below part is used to display the selected image
    let reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event2) => {
      this.imgURL = reader.result;
    };

  }

  saveBook() {
    const uploadData = new FormData();
    uploadData.append('imageFile', this.selectedFile, this.selectedFile.name);
    this.selectedFile.imageName = this.selectedFile.name;
    this.httpClient.post('http://localhost:8080/books/upload', uploadData, { observe: 'response' })
      .subscribe((response) => {
        console.log(response);
        console.log(response.status);
        if (response.status === 200) {
          this.producthttpclientservice.addBook(this.addBookForm.value).subscribe(
            (book) => {
              this.utilsService.showAddProductMsg();
              this.bookAddedEvent.emit();
              this.router.navigate(['admin', 'products']);
            }
          );
          console.log('Image uploaded successfully');
        } else {
          console.log('Image not uploaded successfully');
        }
      }
      );
  
}
}