import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewProductComponent } from './view-product.component';
import { ProductHttpClientService } from '../../../service/product-http-client.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('ViewBookComponent', () => {
  let component: ViewProductComponent;
  let fixture: ComponentFixture<ViewProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewProductComponent ],
      imports: [
        RouterTestingModule,
      ],
      providers:[
      {provide: ProductHttpClientService, useClass : ProductHttpClientServicestub },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewProductComponent);
    component = fixture.componentInstance;
    component.book=name;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

class ProductHttpClientServicestub{
  deleteBook(){

  }
 
}