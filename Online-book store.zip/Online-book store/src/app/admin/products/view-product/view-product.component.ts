import { Component, OnInit,Input, EventEmitter, Output} from '@angular/core';
import { Book } from '../../../model/Book';
import { ProductHttpClientService } from '../../../service/product-http-client.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilsService } from '../../../shared/utils.service';

@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.css']
})
export class ViewProductComponent implements OnInit {
  @Input()
  book: Book;
  @Output()
  bookDeletedEvent = new EventEmitter();
  datafromb:any;
  
  constructor(private producthttpclientservice: ProductHttpClientService,
     private router: Router,
     private utilsService:UtilsService
  ) { }

  ngOnInit() {
    // this.producthttpclientservice.getBookById(this.book.id).subscribe(
    //   (book) => {
    //     this.datafromb=book;
    //   }
    // )
  }

  deleteBook() {
    this.producthttpclientservice.deleteBook(this.book.id).subscribe(
      (book) => {
        this.utilsService.deleteProductMsg();
        this.bookDeletedEvent.emit();
        this.router.navigate(['admin', 'products']);
      }
    );
  }
  editBook() {
    this.router.navigate(['admin', 'products'], { queryParams: { action: 'edit', id: this.book.id } });
  }
}

