import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {FileUploader} from "ng2-file-upload";

@Component({
  selector: 'app-multiple-file-upload',
  templateUrl: './multiple-file-upload.component.html',
  styleUrls: ['./multiple-file-upload.component.css']
})
export class MultipleFileUploadComponent implements OnInit {
  uploadForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.uploadForm = this.fb.group({
      document: [null, null],
      type:  [null, Validators.required]
    }); 
  }
  public uploader:FileUploader = new FileUploader({
    isHTML5: true
  });
  title: string = 'Angular File Upload';
  uploadSubmit(){
    for (let i = 0; i < this.uploader.queue.length; i++) {
      let fileItem = this.uploader.queue[i]._file;
      console.log(fileItem.name);
      if(fileItem.size > 56320){
        alert("Each File should be less than 55 MB of size.");
        return;
      }
    }
    for (let j = 0; j < this.uploader.queue.length; j++) {
      let data = new FormData();
      let fileItem = this.uploader.queue[j]._file;
      var name = this.uploader.queue[j]._file.name;
      console.log(fileItem.name);
      data.append('file', fileItem);
      data.append('fileSeq', 'seq'+j);
      data.append( 'dataType', this.uploadForm.controls.type.value);
      this.uploadFile(data);
     }
    this.uploader.clearQueue();
}

uploadFile(data: FormData) {
// return this.http.post('http://localhost:8080/upload', data);
}


}

