import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './admin/users/users.component'
import { ProductsComponent } from './admin/products/products.component'
import { MenuComponent } from './menu/menu.component';
import { LoginComponent } from '../app/login/login.component';
import { PdfDownloadComponent } from '../app/pdf-download/pdf-download.component';
import { ShopbookComponent } from '../app/shopbook/shopbook.component';
import { MultipleFileUploadComponent } from '../app/multiple-file-upload/multiple-file-upload.component';

const routes: Routes = [
  { path: 'admin/users', component: UsersComponent },
  { path: 'admin/products', component: ProductsComponent },
  { path: 'menu', component: MenuComponent },
  { path: 'pdf', component: PdfDownloadComponent },
  { path: 'shopBook', component:ShopbookComponent},
  { path: 'multiFileUpload', component: MultipleFileUploadComponent},
  { path: '**', component: LoginComponent }
];

@NgModule({
  declarations: [],
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
