import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private baseUrl = 'http://localhost:8080';

  constructor(
    private router: Router,
    private http: HttpClient,
  ) { }

  login(data) {
    console.log(data)
    return this.http.post<any>(`${this.baseUrl}/login`, data);
  }

  getUsers() {
    return this.http.get(`${this.baseUrl}/get`);
  }

}
