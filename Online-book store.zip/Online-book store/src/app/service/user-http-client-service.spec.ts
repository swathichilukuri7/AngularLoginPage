import { TestBed } from '@angular/core/testing';

import { UserHttpClientService } from './user-http-client.service';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/User';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('UserHttpClientService', () => {

  let service : UserHttpClientService;

  beforeEach(() => {  
    TestBed.configureTestingModule({
    providers:[ UserHttpClientService, HttpClient], 
    imports:[ RouterTestingModule, HttpClientTestingModule ] 
  });

  service =TestBed.get(UserHttpClientService); 
});

it('should be created', () => { 
  expect(service).toBeTruthy();
});

describe('get all users', () => {
  it('should return a collection of users', () => {
    const userResponse = [
      {
        id: 1,
        name: 'Harika',
        type: 'admin',
        email:'abcd@gmail.com',
        password: 'Blastoise'
      },
      {
        id: 2,
        name: 'hari',
        type: 'user',
        email:'abcd@gmail.com',
        password: 'Blastoise'
      }
    ];
    let response;
    spyOn(service, 'getUsers').and.returnValue(of(userResponse));

    service.getUsers().subscribe(res => {
        response = res;
      });
      expect(response).toEqual(userResponse);
    });
  });

  it('should have getData function', () => {
    expect(service.getUsers).toBeTruthy();
   });
  

   describe('getUserById', () => {
    it('should return a single user', () => {
      const userResponse = {
        id: '2',
        name: 'hari',
        type: 'user',
        email:'abcd@gmail.com',
        password: 'Blastoise'
      };
      let response;
      spyOn(service, 'getUserById').and.returnValue(of(userResponse));
  
      service.getUserById(2).subscribe(res => {
        response = res;
      });
  
      expect(response).toEqual(userResponse);
    });
  });
}); 
