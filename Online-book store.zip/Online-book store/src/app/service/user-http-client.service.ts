import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserHttpClientService {

  constructor(private httpClient:HttpClient) { }
  baseUrl: string = 'http://localhost:8080/users/';

  getUsers()
  {
    console.log('Getting all users');
    return this.httpClient.get<User[]>('http://localhost:8080/users/get');
  }
  addUser(newUser: User) {
    return this.httpClient.post<User>('http://localhost:8080/users/add', newUser);   
  }
  deleteUser(id) {
    return this.httpClient.delete<User>('http://localhost:8080/users/' + id);
  }
  updateUser(updatedUser: User) {
    return this.httpClient.put<User>('http://localhost:8080/users/update', updatedUser);
  }
  getUserById(id: number) {
    return this.httpClient.get(`${this.baseUrl}user/${id}`);
  }
}
