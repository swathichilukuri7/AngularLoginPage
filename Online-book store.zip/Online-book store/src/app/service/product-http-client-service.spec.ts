import { TestBed } from '@angular/core/testing';

import { ProductHttpClientService } from './product-http-client.service';

describe('ProductHttpClientService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: ProductHttpClientService = TestBed.get(ProductHttpClientService);
//     expect(service).toBeTruthy();
//   });
});