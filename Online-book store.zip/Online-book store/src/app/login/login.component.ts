import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  invalidLogin: boolean = false;
  datafromdb:any;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private loginService: LoginService,
  ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      // email: ['', [Validators.required,Validators.pattern(this.sharedService.emailIdPattern)]],
      email : ['', Validators.required],
      password: ['', Validators.required]

    })
  }
  select: boolean = true;
  email = "";
  password = "";
  doesntExist: boolean = false;
  invalid: boolean = false;

  get f() {
    return this.loginForm.controls;
  }

  logIn() { 
    if(this.loginForm.invalid){
      return; 
    }
    // this.router.navigate(['admin/users']);
    // console.log(this.loginForm.value);
    // this.loginService.login(this.loginForm.value).subscribe((data:any)=>{
    //   console.log(data);     
    // });
    if(this.loginForm.controls.email.value == 'hkottapalli@nisum.com' && this.loginForm.controls.password.value == 'password') {
      localStorage.setItem('user',this.loginForm.controls.email.value );
      // this.messageService.showSuccessBoxAlert();
      this.router.navigate(['admin/users']);
  }else {
    this.invalidLogin = true;
  }
}
}
