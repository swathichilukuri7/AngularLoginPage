import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShopbookComponent } from './shopbook.component';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProductHttpClientService } from '../service/product-http-client.service';
import { of } from 'rxjs';
describe('ShopbookComponent', () => {
  let component: ShopbookComponent;
  let fixture: ComponentFixture<ShopbookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShopbookComponent ],
      imports: [
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule
      ],
      providers:[
        {provide: ProductHttpClientService, useClass : ProductHttpClientServicestub },
        ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShopbookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
class ProductHttpClientServicestub{
  getBooks(){
    return of([]);
  }
}