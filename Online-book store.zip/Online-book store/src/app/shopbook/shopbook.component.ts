import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductHttpClientService } from '../service/product-http-client.service';
import { Book } from '../model/Book';


@Component({
  selector: 'app-shopbook',
  templateUrl: './shopbook.component.html',
  styleUrls: ['./shopbook.component.css']
})
export class ShopbookComponent implements OnInit {
  books: Array<Book>;
  booksRecieved: Array<Book>;
  cartBooks: any;
  books1: Array<Book>;

  constructor(private router: Router, 
    private producthttpclientservice: ProductHttpClientService) { }

  ngOnInit() {
    this.producthttpclientservice.getBooks().subscribe(
      response => {
        this.books = response;
        console.log(response);

        this.books = new Array<Book>();
        this.books1 = response;
        for (const book of this.books1) {

          const book2 = new Book();
          book2.id = book.id;
          book2.name = book.name;
          book2.retrievedImage = 'data:image/jpeg;base64,' + book.imgUrl;
          book2.author = book.author;
          book2.price = book.price;
          book2.imgUrl = book.imgUrl;
          this.books.push(book2);
        }
      }
    );
    let data = localStorage.getItem('cart');
    if (data !== null) {
      this.cartBooks = JSON.parse(data);
    } else {
      this.cartBooks = [];
    }
  }
  
  addToCart(bookId) {
    let book = this.books.find(book => {
      return book.id === +bookId;
    });
    let cartData = [];
    let data = localStorage.getItem('cart');
    if (data !== null) {
      cartData = JSON.parse(data);
    }
    cartData.push(book);
    this.updateCartData(cartData);
    localStorage.setItem('cart', JSON.stringify(cartData));
    book.isAdded = true;
  }

  updateCartData(cartData) {
    this.cartBooks = cartData;
  }

  goToCart() {
    localStorage.getItem('cart');
    // this.router.navigate(['/cart']);
  }

  emptyCart() {
    this.cartBooks = [];
    localStorage.clear();
  }
  remove(index:number){
    this.cartBooks.splice(index,1);
    // localStorage.removeItem([cartData[index]);
  }
}
