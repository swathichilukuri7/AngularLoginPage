import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class UtilsService {

  constructor() { }

  emailIdPattern: string = '^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{3,4})$';
  namePattern: string = '^[a-zA-Z]+(?:[ .]+[a-zA-Z]+)*$';
  numberPattern : string = '^(([1-9]*)|(([1-9]*)\.([0-9]*)))$';
  
  showSuccessAddAlert() {
    return swal.fire(
      'Success!',
      "User has been added successfully",    
    )
  }
  showSuccessUpdateMsg() {
    return swal.fire(
      'Success!',
      "User has been updated successfully",
      
    )
  }
  deleteUserMsg(){
    return swal.fire(
     'Deleted!',
     "User is deleted successfully",
    
    )
  }
    showAddProductMsg() {
    return swal.fire(
      'Success!',
      "Book has been added successfully",
      
    )
  }
  showProductUpdateMsg() {
    return swal.fire(
      'Success!',
      "Book has been updated successfully",
      
    )
  }
  deleteProductMsg(){
    return swal.fire(
     'Deleted!',
     "Book is deleted successfully",
    
    )
  }
}
