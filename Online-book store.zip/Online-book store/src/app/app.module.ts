import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { MenuComponent } from './menu/menu.component';
import { LoginComponent } from './login/login.component';
import { UsersModule } from '../app/admin/users/users/users.module';
import { ProductsModuleModule } from '../app/admin/products/products-module/products-module.module';
import { PdfDownloadComponent } from './pdf-download/pdf-download.component';
import { ShopbookComponent } from './shopbook/shopbook.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MultipleFileUploadComponent } from './multiple-file-upload/multiple-file-upload.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {FileSelectDirective} from "ng2-file-upload";
import { MatSelectModule,MatFormFieldModule, MatInputModule } from '@angular/material';
import { SqrtPipe } from './sqrt.pipe';
@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    LoginComponent,
    PdfDownloadComponent,
    ShopbookComponent,
    MultipleFileUploadComponent,
    FileSelectDirective,
    SqrtPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    UsersModule,
    ProductsModuleModule,
    AngularFontAwesomeModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  providers: [],
  bootstrap: [AppComponent],

})
export class AppModule { }
