export class Book {
    id: number;
    name: string;
    author: string;
    price: number;
    imgUrl: Blob; 
    retrievedImage: string;  
    isAdded: boolean;
}
