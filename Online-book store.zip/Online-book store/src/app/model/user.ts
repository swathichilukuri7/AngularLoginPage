export class User {
    id: number;
    name: string;
    type: string;  
    email:string;
    password: string;
}
