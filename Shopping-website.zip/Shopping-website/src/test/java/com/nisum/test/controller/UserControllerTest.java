package com.nisum.test.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.aspectj.lang.annotation.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import com.nisum.Repository.UserRepository;
import com.nisum.controller.UserController;
import com.nisum.model.User;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserControllerTest {

	@InjectMocks
	UserController userController;
	
	@Mock
	private UserRepository userRepository;
	
	@Mock
	User user;
	
	@Mock
	MultipartFile file;
	
	@Test
	public void testGetUsers() {
		Mockito.when(userRepository.findAll()).thenReturn(getAllUsers());
		userController.getUsers();
		System.out.println(getAllUsers().size());
		assertEquals(3,getAllUsers().size()) ;
	}
	
	@Test
	public void testCreateUser() {
		User user1 = new User(1,"hari","abc@gmail.com","Admin","password");
		Mockito.when(userRepository.save(Mockito.any())).thenReturn(user1);
		userController.createUser(user1);
		System.out.println(user1.getName());
		assertEquals("hari",user1.getName()) ;
	}
	
	@Test
	public void testDeleteUser() {
		User user1 = new User(1,"hari","abc@gmail.com","Admin","password");
		Mockito.when(userRepository.getOne(Mockito.anyLong())).thenReturn(user1);
		userController.deleteUser(1);
		System.out.println(user1.getName());
		assertEquals("hari",user1.getName());
	}
	
	@Test
	public void testUpdateUser() {
		User user1 = new User(1,"hari","abc@gmail.com","Admin","password");
//		user1.setName("harika");
		Mockito.when(userRepository.save(Mockito.any())).thenReturn(user1);
		userController.updateUser(user1);
		System.out.println(user1.getName());
		assertEquals("hari",user1.getName());
	}
//	public void testUpdateImage() {
//		Mockito.doNothing().when(file.getBytes());
//		userController.uploadFile(file);
//		System.out.println(user1.getName());
//		assertEquals("hari",user1.getName());
//	}
	
   private List<User> getAllUsers(){
	   List<User> usersList = new ArrayList<User>();
       User user1 = new User(1,"hari","abc@gmail.com","Admin","password");
       User user2 = new User(1,"harika","xyz@gmail.com","Admin","324");
       User user3 = new User(1,"hh","cde@gmail.com","User","123");
       usersList.add(user1);
       usersList.add(user2);
       usersList.add(user3);
       return usersList;
    
}
}