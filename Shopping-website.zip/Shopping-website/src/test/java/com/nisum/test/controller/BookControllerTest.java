package com.nisum.test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.fileUpload;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

import com.nisum.Repository.BookRepository;
import com.nisum.controller.BookController;
import com.nisum.model.Book;
import com.nisum.model.User;

@RunWith(SpringJUnit4ClassRunner.class)
public class BookControllerTest {

	@InjectMocks
	BookController bookController;
	
	@Mock
	BookRepository bookRepository;
	
	@Mock
	Book book;
	
	@Mock
	MultipartFile file;
	
	@Test
	public void testGetBooks() {
		Mockito.when(bookRepository.findAll()).thenReturn(getAllBooks());
		bookController.getBooks();
		System.out.println(getAllBooks().size());
		assertEquals(2,getAllBooks().size()) ;
	}
	
	@Test
	public void testCreateBook() throws IOException {
		 Book book1 = new Book((long) 1,"secret","author","500","test data".getBytes());
		 Mockito.when(bookRepository.save(Mockito.any())).thenReturn(book1);
		 bookController.createBook(book1);
		 System.out.println(book1.getName());
		 assertEquals("secret",book1.getName()) ;
	}
	
	@Test
	public void testDeleteBook() {
		Book book1 = new Book((long) 1,"secret","author","500","test data".getBytes());
		Mockito.when(bookRepository.getOne(Mockito.anyLong())).thenReturn(book1);
		bookController.deleteBook(1);
		System.out.println(book1.getName());
		assertEquals("secret",book1.getName());
	}
	
	@Test
	public void testUpdateUser() {
		Book book1 = new Book((long) 1,"secret","author","500","test data".getBytes());
		Mockito.when(bookRepository.save(Mockito.any())).thenReturn(book1);
		bookController.updateBook(book1);
		System.out.println(book1.getAuthor());
		assertEquals("author",book1.getAuthor());
	}
	
//	@Test
//	public void testImage() throws IOException {
////		byte[] file ="test data".getBytes();
//		MockMultipartFile file = new MockMultipartFile("data", "filename.txt", "text/plain", "some xml".getBytes());
//			Mockito.doNothing().when(bookRepository.(Mockito.any(MultipartFile.class)));
//			bookController.uploadImage(file);
//			System.out.println(file.getBytes());
//			assertEquals("\"some xml\".getBytes()",file.getBytes());
//		}
//	Book book1 = new Book((long) 1,"secret","author","500","test data".getBytes());
//	Mockito.doNothing().when("file".getBytes());
//	byte[] file ="test data".getBytes();
//	bookController.uploadImage( );;
//	System.out.println(user1.getName());
//	assertEquals("hari",user1.getName());
//    MockMultipartFile file = new MockMultipartFile("data", "filename.txt", "text/plain", "some xml".getBytes());
//    Mockito.doNothing().when(bookController.(bookMockito.any(MultipartFile.class));
//    bookController.uploadImage(file);
//    System.out.println(file.getBytes());
//    assertEquals("\"some xml\".getBytes()",file.getBytes());
   

	
	private List<Book>getAllBooks(){
		 List<Book>booksList = new ArrayList<Book>();
		 
		 Book book1 = new Book((long) 1,"secret","author","500","test data".getBytes());
		 System.out.println(book1);
		 Book book2 = new Book((long) 2,"secret","author","500","test data".getBytes());
		 booksList.add(book1);
		 booksList.add(book2);
		  return booksList;
	    
	}
}
