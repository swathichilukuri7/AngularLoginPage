package com.nisum.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nisum.model.Login;

public interface LoginRepository  extends JpaRepository<Login, Integer> {

}
